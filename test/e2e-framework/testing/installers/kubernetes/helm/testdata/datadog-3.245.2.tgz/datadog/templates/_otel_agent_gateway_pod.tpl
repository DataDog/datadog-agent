{{- define "otel-agent-gateway.controllerType" -}}
{{- $type := .Values.otelAgentGateway.controller.type -}}
{{- if not (or (eq $type "Deployment") (eq $type "StatefulSet")) -}}
{{- fail (printf "otelAgentGateway.controller.type must be \"Deployment\" or \"StatefulSet\", got %q" $type) -}}
{{- end -}}
{{- $type -}}
{{- end -}}

{{- define "otel-agent-gateway.podTemplate" }}
  template:
    metadata:
      labels:
{{ include "datadog.template-labels" . | indent 8 }}
        app.kubernetes.io/component: otel-agent-gateway
        admission.datadoghq.com/enabled: "false"
        app: {{ template "datadog.fullname" . }}-otel-agent-gateway
        {{- if .Values.otelAgentGateway.podLabels }}
{{ toYaml .Values.otelAgentGateway.podLabels | indent 8 }}
        {{- end }}
        {{- if .Values.otelAgentGateway.additionalLabels }}
{{ toYaml .Values.otelAgentGateway.additionalLabels | indent 8 }}
        {{- end }}
{{ include "provider-labels" . | indent 8 }}
      name: {{ template "datadog.fullname" . }}-otel-agent-gateway
      annotations:
        {{- if .Values.agents.customAgentConfig }}
        checksum/agent-config: {{ tpl (toYaml .Values.agents.customAgentConfig) . | sha256sum }}
        {{- end }}
        # It is fine for Gateway Deployment to not have an API key, e.g. in multi-layer Gateway setup.
        {{- if and (not .Values.datadog.apiKeyExistingSecret) (.Values.datadog.apiKey) }}
        checksum/api_key: {{ include (print $.Template.BasePath "/secret-api-key.yaml") . | sha256sum }}
        {{- end }}
        checksum/install_info: {{ printf "%s-%s" .Chart.Name .Chart.Version | sha256sum }}
        {{- if (not .Values.otelAgentGateway.configMap.name) }}
        checksum/otel-gateway-config: {{ include (print $.Template.BasePath "/otel-gateway-configmap.yaml") . | sha256sum }}
        {{- else if .Values.otelAgentGateway.configMap.checksum }}
        checksum/otel-gateway-config: {{ .Values.otelAgentGateway.configMap.checksum }}
        {{- end }}
      {{- if .Values.otelAgentGateway.podAnnotations }}
{{ tpl (toYaml .Values.otelAgentGateway.podAnnotations) . | indent 8 }}
      {{- end }}
    spec:
      {{- if .Values.otelAgentGateway.shareProcessNamespace }}
      shareProcessNamespace: {{ .Values.otelAgentGateway.shareProcessNamespace }}
      {{- end }}
      {{- if .Values.otelAgentGateway.priorityClassName }}
      priorityClassName: "{{ .Values.otelAgentGateway.priorityClassName }}"
      {{- end }}
      {{- if .Values.otelAgentGateway.image.pullSecrets }}
      imagePullSecrets:
{{ toYaml .Values.otelAgentGateway.image.pullSecrets | indent 8 }}
      {{- end }}
      {{- if .Values.otelAgentGateway.useHostNetwork }}
      hostNetwork: {{ .Values.otelAgentGateway.useHostNetwork }}
      dnsPolicy: ClusterFirstWithHostNet
      {{- end }}
      {{- if .Values.otelAgentGateway.dnsConfig }}
      dnsConfig:
{{ toYaml .Values.otelAgentGateway.dnsConfig | indent 8 }}
      {{- end }}
      {{- if .Values.otelAgentGateway.rbac.create  }}
      serviceAccountName: {{ include "agents.serviceAccountName" . }}
      {{- end }}
      initContainers:
      - name: init-volume
        image: "{{ include "ddot-collector-gateway-image" . }}"
        imagePullPolicy: {{ .Values.otelAgentGateway.image.pullPolicy }}
        command:
          - cp
          - -r
        args:
          - /etc/datadog-agent
          - /opt
        volumeMounts:
          - name: config
            mountPath: /opt/datadog-agent
{{- if .Values.otelAgentGateway.initContainers.securityContext }}
        securityContext:
{{ toYaml .Values.otelAgentGateway.initContainers.securityContext | indent 10 }}
{{- end }}
{{- if .Values.otelAgentGateway.initContainers.resources }}
        resources:
{{ toYaml .Values.otelAgentGateway.initContainers.resources | indent 10 }}
{{- end }}
      containers:
      - name: otel-agent
        image: "{{ include "ddot-collector-gateway-image" . }}"
        imagePullPolicy: {{ .Values.otelAgentGateway.image.pullPolicy }}
        {{- if .Values.otelAgentGateway.lifecycle }}
        lifecycle:
{{ toYaml .Values.otelAgentGateway.lifecycle | indent 10 }}
        {{- end }}
        {{- if eq .Values.targetSystem "linux" }}
        command:
          - "otel-agent"
          {{- if and .Values.agents.useConfigMap (eq .Values.targetSystem "linux")}}
          - "--core-config={{ template "datadog.confPath" .  }}/datadog.yaml"
          {{- end }}
          - "--sync-delay=30s"
        args:
          {{- if .Values.otelAgentGateway.configMap.items }}
          {{- range .Values.otelAgentGateway.configMap.items }}
          - "--config={{ template "datadog.otelconfPath" $ }}/{{ .path }}"
          {{- end }}
          {{- else }}
          - "--config={{ template "datadog.otelconfPath" . }}/otel-gateway-config.yaml"
          {{- end }}
          {{- if .Values.otelAgentGateway.featureGates }}
          - "--feature-gates={{ .Values.otelAgentGateway.featureGates }}"
          {{- end }}
        {{- end -}}
        {{- if eq .Values.targetSystem "windows" }}
        command:
          - "otel-agent"
          - "-foreground"
          # - "--core-config={{ template "datadog.confPath" .  }}/datadog.yaml"
          - "--sync-delay=30s"
          {{- if .Values.otelAgentGateway.configMap.items }}
          {{- range .Values.otelAgentGateway.configMap.items }}
          - "-config={{ template "datadog.otelconfPath" $ }}/{{ .path }}"
          {{- end }}
          {{- else }}
          - "-config={{ template "datadog.otelconfPath" . }}/otel-gateway-config.yaml"
          {{- end }}
          {{- if .Values.otelAgentGateway.featureGates }}
          - "--feature-gates={{ .Values.otelAgentGateway.featureGates }}"
          {{- end }}
        {{- end -}}
        {{- if .Values.otelAgentGateway.containers.otelAgent.securityContext }}
        securityContext:
{{ toYaml .Values.otelAgentGateway.containers.otelAgent.securityContext | indent 10 }}
        {{- else }}
{{ include "generate-security-context" (dict "targetSystem" .Values.targetSystem "seccomp" "" "kubeversion" .Capabilities.KubeVersion.Version) | indent 8 }}
        {{- end }}
        resources:
{{ toYaml .Values.otelAgentGateway.containers.otelAgent.resources | indent 10 }}
        ports:
          {{- range .Values.otelAgentGateway.ports }}
            - containerPort: {{ .containerPort }}
              {{- if .hostPort }}
              hostPort: {{ .hostPort }}
              {{- end }}
              protocol: {{ .protocol | default "TCP" }}
              name: {{ .name }}
          {{- end }}
      {{- if .Values.otelAgentGateway.containers.otelAgent.envFrom }}
        envFrom:
{{ .Values.otelAgentGateway.containers.otelAgent.envFrom | toYaml | indent 10 }}
      {{- end }}
        env:
          # It is fine for Gateway Deployment to not have an API key, e.g. in multi-layer Gateway setup.
          {{- if (or (.Values.datadog.apiKeyExistingSecret) (.Values.datadog.apiKey)) }}
          - name: DD_API_KEY
            valueFrom:
              secretKeyRef:
                name: {{ template "datadog.apiSecretName" . }}
                key: api-key
          {{- end }}
          - name: DD_OTELCOLLECTOR_ENABLED
            value: "true"
          - name: DD_OTELCOLLECTOR_INSTALLATION_METHOD
            value: "kubernetes"
          - name: DD_OTELCOLLECTOR_GATEWAY_MODE
            value: "true"
          - name: DD_OTEL_STANDALONE
            value: "false"
          - name: DD_HOSTNAME
            valueFrom:
              fieldRef:
                fieldPath: spec.nodeName
          - name: DD_OTELCOLLECTOR_CONVERTER_FEATURES
            value: "zpages,pprof,datadog" # exclude infra attribute, prometheus and DD flare; health_check is configured explicitly in the OTel config

          # A subset of components-common-env that makes sense to otel agent in gateway
          {{- if .Values.datadog.site }}
          - name: DD_SITE
            value: {{ .Values.datadog.site | quote }}
          {{- end }}
          {{- if .Values.datadog.dd_url }}
          - name: DD_DD_URL
            value: {{ .Values.datadog.dd_url | quote }}
          {{- end }}
          {{- if .Values.datadog.clusterName }}
          {{- template "check-cluster-name" . }}
          - name: DD_CLUSTER_NAME
            value: {{ tpl .Values.datadog.clusterName . | quote }}
          {{- end }}
          {{- if .Values.datadog.tags }}
          - name: DD_TAGS
            value: {{ tpl (.Values.datadog.tags | join " " | quote) . }}
          {{- end }}

          # Disable features that are not needed / won't work in standalone ddot-collector
          - name: DD_ENABLE_METADATA_COLLECTION
            value: "false"
          - name: DD_PROCESS_AGENT_ENABLED
            value: "false"
          - name: DD_REMOTE_CONFIGURATION_ENABLED
            value: "false"
          - name: DD_INVENTORIES_ENABLED
            value: "false"
          - name: DD_CMD_PORT
            value: "0"
          - name: DD_AGENT_IPC_PORT
            value: "0"
          - name: DD_AGENT_IPC_CONFIG_REFRESH_INTERVAL
            value: "0"
          - name: DD_LOG_LEVEL
            value: {{ .Values.otelAgentGateway.containers.otelAgent.logLevel | default .Values.datadog.logLevel | quote }}
{{- include "additional-env-entries" .Values.otelAgentGateway.containers.otelAgent.env | indent 10 }}
{{- include "additional-env-dict-entries" .Values.otelAgentGateway.containers.otelAgent.envDict | indent 10 }}
        volumeMounts:
          - name: otelgatewayconfig
            mountPath: {{ template "datadog.otelconfPath" . }}
            readOnly: true
          - name: varlog
            mountPath: /var/log/datadog
            readOnly: false
          - name: tmpdir
            mountPath: /tmp
            readOnly: false
          - name: config
            mountPath: {{ template "datadog.confPath" . }}
            readOnly: true
          {{- if and .Values.agents.useConfigMap (eq .Values.targetSystem "linux")}}
          - name: datadog-yaml
            mountPath: {{ template "datadog.confPath" . }}/datadog.yaml
            subPath: datadog.yaml
            readOnly: true
          {{- end }}
      {{- if .Values.otelAgentGateway.volumeMounts }}
{{ toYaml .Values.otelAgentGateway.volumeMounts | indent 10 }}
      {{- end }}
{{- if .Values.otelAgentGateway.containers.otelAgent.livenessProbe.enabled }}
        livenessProbe:
{{ include "probe.http" (dict "path" "/" "port" .Values.otelAgentGateway.containers.otelAgent.healthPort "settings" (omit .Values.otelAgentGateway.containers.otelAgent.livenessProbe "enabled")) | indent 10 }}
{{- end }}
{{- if .Values.otelAgentGateway.containers.otelAgent.readinessProbe.enabled }}
        readinessProbe:
{{ include "probe.http" (dict "path" "/" "port" .Values.otelAgentGateway.containers.otelAgent.healthPort "settings" (omit .Values.otelAgentGateway.containers.otelAgent.readinessProbe "enabled")) | indent 10 }}
{{- end }}
      volumes:
      - name: varlog
        emptyDir: {}
      - name: tmpdir
        emptyDir: {}
      - name: config
        emptyDir: {}
      - name: otelgatewayconfig
        configMap:
          {{- if .Values.otelAgentGateway.configMap.name }}
          name: {{ .Values.otelAgentGateway.configMap.name }}
          {{- if .Values.otelAgentGateway.configMap.items }}
          items:
            {{- range .Values.otelAgentGateway.configMap.items }}
            - key: {{ .key }}
              path: {{ .path }}
            {{- end }}
          {{- else if .Values.otelAgentGateway.configMap.key }}
          items:
            - key: {{ .Values.otelAgentGateway.configMap.key }}
              path: otel-gateway-config.yaml
          {{- end }}
          {{- else }}
          name: {{ include "agents-install-otel-gateway-configmap-name" . }}
          items:
            - key: otel-gateway-config.yaml
              path: otel-gateway-config.yaml
          {{- end }}
{{- if .Values.otelAgentGateway.volumes }}
{{ toYaml .Values.otelAgentGateway.volumes | indent 6 }}
{{- end }}
      {{- if .Values.otelAgentGateway.terminationGracePeriodSeconds }}
      terminationGracePeriodSeconds: {{ .Values.otelAgentGateway.terminationGracePeriodSeconds }}
      {{- end }}
      {{- if .Values.otelAgentGateway.tolerations }}
      tolerations:
{{ toYaml .Values.otelAgentGateway.tolerations | indent 8 }}
      {{- end }}
{{- if .Values.otelAgentGateway.affinity }}
      affinity:
{{ toYaml .Values.otelAgentGateway.affinity | indent 8 }}
{{- end }}
      nodeSelector:
        {{ template "label.os" . }}: {{ .Values.targetSystem }}
      {{- if .Values.otelAgentGateway.nodeSelector }}
{{ toYaml .Values.otelAgentGateway.nodeSelector | indent 8 }}
      {{- end }}
      {{- with .Values.otelAgentGateway.topologySpreadConstraints }}
      topologySpreadConstraints:
        {{- toYaml . | nindent 8 }}
      {{- end }}
{{- end }}
